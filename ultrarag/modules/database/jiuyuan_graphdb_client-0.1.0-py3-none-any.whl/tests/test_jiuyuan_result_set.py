import unittest
import pandas as pd
from jiuyuan_db.jiuyuan_result_set import JiuyuanResultSet


class TestJiuyuanResultSet(unittest.TestCase):

    def setUp(self):
        self.result_set = JiuyuanResultSet(["name", "age"],
                                           [["zhangsan", 18], ["lisi", 20]])
        self.result_set.next()
        self.vertex_result_set = JiuyuanResultSet(["vertex"],
                                                  [[
                                                      '''{"id": 2251799813685424, "label": "Person", "properties": {
                                                       "name": "Joe"}}::vertex''']])
        self.vertex_result_set.next()

        self.edge_result_set = JiuyuanResultSet(["edge"],
                                                [['''{"id": 2533274790396576, "label": "workWith", 
                                                    "end_id": 2251799813685425, "start_id": 2251799813685424, 
                                                    "properties": {"weight": 3}}::edge''']])
        self.edge_result_set.next()

        p = '''[{"id": 844424930131978, "label": "Person", "properties": {"id": "10", "__id__": 10}}::vertex, 
        {"id": 1125899906842633, "label": "Knows", "end_id": 844424930131978, "start_id": 844424930131969, "properties": {}}::edge,
        {"id": 844424930131969, "label": "Person", "properties": {"id": "1", "__id__": 1}}::vertex]::path'''

        self.path_result_set = JiuyuanResultSet(["p"], [[p]])
        self.path_result_set.next()
    #
    def test_get_result_list(self):
        self.assertEqual(self.result_set.get_result_list(), [["zhangsan", 18], ["lisi", 20]])

    def test_get_string(self):
        self.assertEqual(self.result_set.get_string(1), "zhangsan")

    def test_get_int(self):
        self.assertEqual(self.result_set.get_int(2), 18)

    def test_get_column_names(self):
        self.assertEqual(self.result_set.get_column_names(), ["name", "age"])

    def test_get_column_count(self):
        self.assertEqual(self.result_set.get_column_count(), 2)

    def test_get_vertex(self):
        self.assertEqual(self.vertex_result_set.get_vertex(1).id, 2251799813685424)
        self.assertEqual(self.vertex_result_set.get_vertex(1).label, "Person")
        self.assertEqual(self.vertex_result_set.get_vertex(1).properties, {"name": "Joe"})

    def test_get_edge(self):
        self.assertEqual(self.edge_result_set.get_edge(1).id, 2533274790396576)
        self.assertEqual(self.edge_result_set.get_edge(1).label, "workWith")
        self.assertEqual(self.edge_result_set.get_edge(1).start_id, 2251799813685424)
        self.assertEqual(self.edge_result_set.get_edge(1).end_id, 2251799813685425)
        self.assertEqual(self.edge_result_set.get_edge(1).properties, {"weight": 3})

    def test_get_path(self):
        self.assertEqual(self.path_result_set.get_path(1)[0].id, 844424930131978)
        self.assertEqual(self.path_result_set.get_path(1)[0].label, "Person")
        self.assertEqual(self.path_result_set.get_path(1)[0].properties, {"id": "10", "__id__": 10})
        self.assertEqual(self.path_result_set.get_path(1)[1].id, 1125899906842633)
        self.assertEqual(self.path_result_set.get_path(1)[1].label, "Knows")
        self.assertEqual(self.path_result_set.get_path(1)[1].start_id, 844424930131969)
        self.assertEqual(self.path_result_set.get_path(1)[1].end_id, 844424930131978)
        self.assertEqual(self.path_result_set.get_path(1)[1].properties, {})
        self.assertEqual(self.path_result_set.get_path(1)[2].id, 844424930131969)
        self.assertEqual(self.path_result_set.get_path(1)[2].label, "Person")
        self.assertEqual(self.path_result_set.get_path(1)[2].properties, {"id": "1", "__id__": 1})

    if __name__ == '__main__':
        unittest.main()
