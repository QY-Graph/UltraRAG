from typing import List, Literal, Optional, Tuple, Type, Union
# from uuid import UUID

from sqlalchemy.dialects.postgresql import UUID, JSONB

from numpy import ndarray
from sqlalchemy import (
    BIGINT,
    Column,
    ColumnElement,
    Float,
    create_engine,
    delete,
    func,
    insert,
    select,
    text, MetaData,
)
from sqlalchemy.dialects import postgresql
from sqlalchemy.dialects.postgresql.pg_catalog import pg_class
from sqlalchemy.engine import Engine
from sqlalchemy.ext.automap import automap_base
from sqlalchemy.orm import mapped_column, declarative_base
from sqlalchemy.orm.session import Session
from sqlalchemy.types import String
from sqlalchemy.ext.asyncio import AsyncEngine, create_async_engine, AsyncSession
from jiuyuan_db.vector.errors import CountRowsEstimateCondError
from jiuyuan_db.vector.sdk.filters import Filter
from jiuyuan_db.vector.sdk.record import Record, RecordORM, RecordORMType, Unique
from jiuyuan_db.vector.vector_sqlalchemy import VECTOR

Base = declarative_base()

def table_factory(
    collection_name: str,
    dimension: int,
    table_args,
    base_class: Type[RecordORM] = RecordORM,
) -> type:
    def __init__(self, **kwargs):
        base_class.__init__(self, **kwargs)

    return type(
        collection_name,
        (base_class,),
        {
            "__init__": __init__,
            "__tablename__": f"collection_{collection_name}",
            "__table_args__": table_args,
            "id": mapped_column(
                postgresql.UUID(as_uuid=True),
                primary_key=True,
            ),
            "text": mapped_column(String),
            "meta": mapped_column(postgresql.JSONB),
            "embedding": mapped_column(VECTOR(dimension)),
        },
    )

class JiuyuanVector:
    _engine: "Engine"
    _async_engine: AsyncEngine

    def __init__(self, db_url: str) -> None:
        self.db_url = db_url
        self._engine = create_engine(db_url)
        self._async_engine = create_async_engine(db_url)

        with Session(self._engine) as session:
            session.execute(text("CREATE EXTENSION IF NOT EXISTS vectors"))
            session.commit()

        self._table_class_cache = {}

        postgresql.base.ischema_names["vector"] = VECTOR
        self.metadata = MetaData()

    @classmethod
    def from_config(
        cls, host: str, port: int, user: str, password: str, db_name: str
    ) -> "JiuyuanVector":
        db_url = f"postgresql+psycopg://{user}:{password}@{host}:{port}/{db_name}"
        return cls(db_url)

    def _get_or_create_table_class(
            self,
            collection_name: str,
            dimension: Optional[int] = None,
            table_args=None,
    ) -> Type:
        """
        Return the ORM class for a collection. If it doesn't exist in cache,
        it will be created from schema reflection or provided dimension.

        Args:
            collection_name (str): Name of the collection.
            dimension (Optional[int]): Required if table is not yet created.
            table_args: Used when creating a new table class.

        Returns:
            ORM-mapped class for the collection table.
        """
        if collection_name in self._table_class_cache:
            return self._table_class_cache[collection_name]

        table_name = f"collection_{collection_name}"
        self.metadata.reflect(bind=self._engine)

        if table_name not in self.metadata.tables:
            if dimension is None:
                raise ValueError(f"Table '{table_name}' does not exist and dimension is not provided.")
            orm_class = table_factory(collection_name, dimension, table_args or {"extend_existing": True})
        else:
            reflected_table = self.metadata.tables[table_name]
            embedding_col = reflected_table.columns.get("embedding")
            if embedding_col is None:
                raise ValueError(f"'embedding' column not found in {table_name}")
            col_type = embedding_col.type
            if not isinstance(col_type, VECTOR):
                raise TypeError(f"Expected VECTOR column, got {type(col_type)}")
            dimension = col_type.dim

            orm_class = table_factory(
                collection_name,
                dimension,
                table_args={"extend_existing": True}
            )

        self._table_class_cache[collection_name] = orm_class
        return orm_class

    def create_table_sync(
            self,
            collection_name: str,
            dimension: int,
            recreate: bool = False,
            constraints: Optional[List[Unique]] = None,
    ) -> None:
        """
        Create a new table for the given collection (synchronously).
        Args:
            collection_name (str): Name of the collection.
            dimension (int): Embedding dimension.
            recreate (bool): Whether to drop the table if it exists.
            constraints (Optional[List[Unique]]): Additional column constraints.
        """
        # Set table arguments
        table_args = {"extend_existing": True} if not constraints else (
            *[col.make() for col in constraints],
            {"extend_existing": True},
        )
        table = self._get_or_create_table_class(collection_name, dimension, table_args)

        with self._engine.begin() as conn:
            if recreate:
                table.__table__.drop(bind=conn, checkfirst=True)
            table.__table__.create(bind=conn, checkfirst=True)

    async def create_table(
        self,
        collection_name: str,
        dimension: int,
        recreate: bool = False,
        constraints: Optional[List[Unique]] = None,
    ) -> None:
        """
        Create a new table for the given collection.
        Args:
            collection_name (str): Name of the collection.
            dimension (int): Embedding dimension.
            recreate (bool): Whether to drop the table if it exists.
            constraints (Optional[List[Unique]]): Additional column constraints.
        """
        # Set table arguments
        table_args = {"extend_existing": True} if not constraints else (
            *[col.make() for col in constraints],
            {"extend_existing": True},
        )
        table = self._get_or_create_table_class(collection_name, dimension, table_args)

        async with self._async_engine.begin() as conn:
            if recreate:
                await conn.run_sync(table.__table__.drop, checkfirst=True)
            await conn.run_sync(table.__table__.create, checkfirst=True)

    async def insert(self, collection_name: str, records: List[Record]) -> None:
        """
        Insert records into the specified collection.
        Args:
            collection_name (str): Collection name (without the prefix).
            records (List[Record]): List of records to insert.
        """
        table_cls = self._get_or_create_table_class(collection_name)

        if table_cls is None:
            raise ValueError(f"Table {table_cls} does not exist.")

        async with AsyncSession(self._async_engine) as session:
            for record in records:
                await session.execute(
                    insert(table_cls).values(
                        id=record.id,
                        text=record.text,
                        meta=record.meta,
                        embedding=record.embedding,
                    )
                )
            await session.commit()

    async def search(
        self,
        collection_name: str,
        embedding: Union[ndarray, List[float]],
        distance_op: Literal["<->", "<=>", "<#>"] = "<->",
        top_k: int = 4,
        filter: Optional[Filter] = None,
    ) -> List[Tuple[Record, float]]:
        """
        Search for the nearest records in the specified collection.
        Args:
            collection_name (str): Collection name (without the prefix).
            embedding (Union[ndarray, List[float]]): Target embedding.
            distance_op (Literal["<->", "<=>", "<#>"]): Distance operator.
            top_k (int): Maximum number of records to return.
            filter (Optional[Filter]): Additional filtering condition.
        Returns:
            List of tuples containing a Record and its distance.
        """

        table_cls = self._get_or_create_table_class(collection_name)

        if table_cls is None:
            raise ValueError(f"Table collection_{collection_name} does not exist.")

        async with AsyncSession(self._async_engine) as session:
            stmt = (
                select(
                    table_cls,
                    table_cls.embedding.op(distance_op, return_type=Float)(
                        embedding
                    ).label("distance"),
                )
                .limit(top_k)
                .order_by("distance")
            )
            if filter is not None:
                stmt = stmt.where(filter(table_cls))
            result = await session.execute(stmt)
            rows = result.all()
            return [(Record.from_orm(row[0]), row[1]) for row in rows]

    async def drop_table(self, collection_name: str) -> None:
        """
        Drop the table associated with the given collection name.

        Args:
            collection_name (str): The name of the collection to drop.
        """
        table_name = f"collection_{collection_name}"

        async with AsyncSession(self._async_engine) as session:
            await session.execute(text(f"DROP TABLE IF EXISTS {table_name}"))
            await session.commit()

        # Remove from class cache if present
        if hasattr(self, "_table_class_cache") and collection_name in self._table_class_cache:
            del self._table_class_cache[collection_name]

    def get_collections(self):
        self.metadata.reflect(bind=self._engine)
        return [table_name for table_name in self.metadata.tables if table_name.startswith("collection_")]