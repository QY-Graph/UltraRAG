from typing import List, Dict, Any, Optional, Union, Tuple, Literal
from numpy import ndarray

from jiuyuan_db.vector.sdk.client import JiuyuanVector
from jiuyuan_db.vector.sdk.filters import Filter
from jiuyuan_db.vector.sdk.record import Record


def _record_to_dict(record: Record) -> dict:
    """
    Convert a Record instance to a dictionary.

    Args:
        record: An instance of Record.

    Returns:
        A dictionary representation of the Record.
    """
    return {
        "id": str(record.id),
        "text": record.text,
        "meta": record.meta,
        "embedding": record.embedding
    }

class VectorStore:
    def __init__(self, host: str, port: int, user: str, password: str, db_name: str) -> None:
        self.client = JiuyuanVector(host, port, user, password, db_name)


    async def create(self, collection_name: str, dimension: int) -> None:
        """
        Create a new vector collection with the specified dimension.
        """
        await self.client.create_table(collection_name, dimension)

    async def insert(self, collection_name: str, payloads: List[Dict[str, Any]]) -> None:
        """
        Insert records into the collection.
        """
        records = [Record.from_text(text=payload["text"], embedding=payload["embedding"], meta=payload["metadata"])
                   for payload in payloads]
        await self.client.insert(collection_name, records)


    async def search(
        self,
        collection_name: str,
        embedding: Union[ndarray, List[float]],
        top_k: int = 4,
        distance_op: Literal["<->", "<=>", "<#>"] = "<->",
        filter: Optional[Filter] = None,
    ) -> List[Tuple[dict, float]]:
        """
        Search for similar records in the collection based on the given embedding.
        Optionally, a filter can be applied to narrow down the search.
        """
        results = await self.client.search(collection_name, embedding, top_k=top_k, distance_op=distance_op, filter=filter)

        converted_results = [
            (
                _record_to_dict(record),
                distance
            )
            for record, distance in results
        ]
        return converted_results

    async def remove(self, collection_name: str) -> None:
        """
        Remove (drop) the specified collection.
        """
        await self.client.drop_table(collection_name)
