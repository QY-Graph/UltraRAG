import asyncio
import uuid
from typing import List

import numpy as np

from jiuyuan_db.vector.sdk import Record
from jiuyuan_db.vector.sdk.client import JiuyuanVector

async def main():
    # Configure connection parameters (update these as needed).
    host = "localhost",
    port = 5432,
    user = "postgres",
    password = "mysecretpassword",
    db_name = "postgres"

    # Create an instance of JiuyuanVector.
    vector_app = JiuyuanVector.from_config(host="localhost", port=5432, user="postgres",
                               password="mysecretpassword", db_name="postgres")

    # Define collection details.
    collection_name = "example"
    dimension = 3

    # Create (or recreate) the table for this collection.
    await vector_app.create_table(collection_name, dimension, recreate=True)
    print(f"Table for collection '{collection_name}' created.")

    # Prepare some dummy records.
    dummy_payloads = [
        {
            "text": "This is a test record.",
            "embedding": np.random.rand(dimension).tolist(),  # Convert np array to list
            "meta": {"category": "test", "id": 1}
        },
        {
            "text": "Another record with different text.",
            "embedding": np.random.rand(dimension).tolist(),
            "meta": {"category": "test", "id": 2}
        },
    ]

    # Insert records into the collection.
    print("Inserting records...")
    records = [
        Record.from_text(text=node["text"], embedding=node["embedding"], meta=node["meta"])
        for node in dummy_payloads
    ]

    # Insert the records into the collection.
    await vector_app.insert(collection_name, records)
    print(f"Inserted {len(records)} records into collection '{collection_name}'.")

    # Perform a search using a target embedding.
    search_embedding = [1.0, 1.0, 1.0]
    results = await vector_app.search(collection_name, search_embedding, top_k=3)
    print("Search results:")
    for rec, distance in results:
        print(f"Record ID: {rec.id}, Text: {rec.text}, Distance: {distance}")

    # Retrieve all collections.
    collections = vector_app.get_collections()
    print(collections)

    # Drop the collection.
    await vector_app.drop_table(collection_name)
    print(f"Collection '{collection_name}' dropped.")

if __name__ == "__main__":
    asyncio.run(main())