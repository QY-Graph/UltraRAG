import numpy as np

from jiuyuan_db.vector.sdk import Record
from vector_store import VectorStore


def main():
    # Initialize the vector client with database credentials.
    vector_client = VectorStore(
        host="localhost",
        port=5432,
        user="postgres",
        password="mysecretpassword",
        db_name="postgres"
    )

    collection_name = "test_collection"
    dimension = 1024

    # Create the collection (e.g. index in the backend)
    print("Creating collection...")
    vector_client.create(collection_name, dimension)

    # Prepare dummy payloads.
    # Each payload should have 'text', 'embedding' and 'meta'
    dummy_payloads = [
        {
            "text": "This is a test record.",
            "embedding": np.random.rand(dimension).tolist(),  # Convert np array to list
            "meta": {"category": "test", "id": 1}
        },
        {
            "text": "Another record with different text.",
            "embedding": np.random.rand(dimension).tolist(),
            "meta": {"category": "test", "id": 2}
        },
    ]

    # Insert records into the collection.
    print("Inserting records...")
    records = [
        Record.from_text(text=node["text"], embedding=node["embedding"], meta=node["meta"])
        for node in dummy_payloads
    ]
    vector_client.insert(collection_name, records)

    # Use one of the record's embeddings as the query for a search.
    query_embedding = dummy_payloads[0]["embedding"]

    # Perform a search for similar records.
    print("Searching for similar records...")
    results = vector_client.search(collection_name, query_embedding, top_k=2)

    # Print out the search results.
    for idx, (record_dict, distance) in enumerate(results, 1):
        print(f"Result {idx}:")
        print(f"  Record: {record_dict}")
        print(f"  Distance: {distance}")

    # Remove the collection.
    print("Removing collection...")
    import asyncio
    asyncio.run(vector_client.remove(collection_name))
    print("Collection removed.")


if __name__ == "__main__":
    main()
