import json
import logging

from typing import Any, List, NamedTuple, Optional, Type

from llama_index.core.bridge.pydantic import PrivateAttr
from llama_index.core.schema import BaseNode, MetadataMode
from llama_index.core.vector_stores.types import (
    BasePydanticVectorStore,
    FilterOperator,
    MetadataFilters,
    MetadataFilter,
    VectorStoreQuery,
    VectorStoreQueryResult,
)
from llama_index.core.vector_stores.utils import (
    metadata_dict_to_node,
    node_to_metadata_dict,
)
from sqlalchemy.orm import declarative_base
from sqlalchemy.sql.selectable import Select

from jiuyuan_db.client.client import JiuyuanClient
from jiuyuan_db.jiuyuan_result_set import JiuyuanResultSet


class DBEmbeddingRow(NamedTuple):
    node_id: str  # FIXME: verify this type hint
    text: str
    metadata: dict
    similarity: float


def get_data_model(
        base: Type,
        table_name: str,
        schema_name: str,
        embed_dim: int,
        use_jsonb: bool = True
) -> Any:
    """
    This part create a dynamic sqlalchemy model with a new table.
    """
    from pgvector.sqlalchemy import Vector
    from sqlalchemy import Column
    from sqlalchemy.dialects.postgresql import BIGINT, JSON, JSONB, VARCHAR

    tablename = "vector_data_%s" % table_name  # dynamic table name
    class_name = "Data%s" % table_name  # dynamic class name

    metadata_dtype = JSONB if use_jsonb else JSON

    class AbstractData(base):  # type: ignore
        __abstract__ = True  # this line is necessary
        id = Column(BIGINT, primary_key=True, autoincrement=True)
        text = Column(VARCHAR, nullable=False)
        metadata_ = Column(metadata_dtype)
        node_id = Column(VARCHAR)
        embedding = Column(Vector(embed_dim))  # type: ignore
        embed_vector_dim = embed_dim

    model = type(
        class_name,
        (AbstractData,),
        {"__tablename__": tablename, "__table_args__": {"schema": schema_name}},
    )

    return model


class JiuyuanVectorStore(BasePydanticVectorStore):
    stores_text: bool = True
    perform_setup: bool
    debug: bool
    host: str
    port: int
    user: str
    password: str
    schema_name: str
    database_name: str
    _table_class: Any = PrivateAttr()
    _base: Any = PrivateAttr()
    _is_initialized: bool = PrivateAttr(default=False)
    _client: JiuyuanClient = PrivateAttr()
    _logger = PrivateAttr(default=logging.getLogger("JiuyuanVectorStore"))

    def __init__(self,
                 host: str,
                 port: int,
                 user: str,
                 password: str,
                 database_name: str,
                 table_name: str,
                 embed_dim: int,
                 schema_name: str = "public",
                 perform_setup: bool = True,
                 debug: bool = False
                 ):

        super().__init__(
            table_name=table_name,
            schema_name=schema_name,
            embed_dim=embed_dim,
            perform_setup=perform_setup,
            debug=debug,
            use_jsonb=False,
            host=host,
            port=port,
            user=user,
            password=password,
            database_name=database_name
        )

        self._base = declarative_base()
        self._table_class = get_data_model(
            self._base,
            table_name=table_name,
            schema_name=schema_name,
            embed_dim=embed_dim,
            use_jsonb=False,
        )

    def _connect(self) -> Any:
        jiuyuan_client = JiuyuanClient(host=self.host,
                                       port=self.port,
                                       user=self.user,
                                       password=self.password,
                                       database_name=self.database_name)
        self._client = jiuyuan_client
        return

    def _create_schema_if_not_exists(self) -> None:
        sql_str = f'CREATE SCHEMA IF NOT EXISTS {self._table_class.__table_args__["schema"]}'
        session = self._client.get_session()
        session.execute_sql_update(sql_str)
        self._client.release_session(session)

    def clear(self) -> None:
        self.delete(metadata_filters=None)

    def _create_tables_if_not_exists(self) -> None:
        # from sqlalchemy.schema import CreateTable
        # sql_str = str(CreateTable(self._table_class.__table__, if_not_exists=True).compile(compile_kwargs={"literal_binds": True}))
        # print(sql_str)
        schema = self._table_class.__table_args__["schema"]
        table = self._table_class.__tablename__
        sql_str = (
            f'CREATE TABLE IF NOT EXISTS {schema}.{table} ('
            'id BIGSERIAL NOT NULL,'
            'text VARCHAR NOT NULL,'
            'metadata_ JSONB,'
            'node_id VARCHAR,'
            f'embedding VECTOR({self._table_class.embed_vector_dim}),'
            'PRIMARY KEY (id))')

        index_str = (f'CREATE INDEX IF NOT EXISTS {table}_metadata_idx ON {schema}.{table} USING GIN(metadata_);'
                     f'CREATE INDEX IF NOT EXISTS {table}_embedding_hnsw_cosine_idx ON {schema}.{table} USING hnsw (embedding vector_cosine_ops);')

        session = self._client.get_session()
        session.execute_sql_update(sql_str)
        session.execute_sql_update(index_str)
        self._client.release_session(session)

    def _initialize(self) -> None:
        if not self._is_initialized:
            self._connect()
            if self.perform_setup:
                #     self._create_extension()
                self._create_schema_if_not_exists()
                self._create_tables_if_not_exists()
            self._is_initialized = True

    @property
    def client(self) -> Any:
        return self._client

    def delete(self, metadata_filters: Optional[MetadataFilters], **delete_kwargs: Any) -> None:
        from sqlalchemy import delete
        stmt = delete(self._table_class)
        if metadata_filters:
            stmt = stmt.where(self._recursively_apply_filters(metadata_filters))

        stmt_str = stmt.compile(compile_kwargs={"literal_binds": True})
        if self.debug is True:
            self._logger.debug(f"Executing delete query: {stmt_str}")
        session = self._client.get_session()
        session.execute_sql_update(str(stmt_str))
        self._client.release_session(session)
        return

    def _to_postgres_operator(self, operator: FilterOperator) -> str:
        if operator == FilterOperator.EQ:
            return "="
        elif operator == FilterOperator.GT:
            return ">"
        elif operator == FilterOperator.LT:
            return "<"
        elif operator == FilterOperator.NE:
            return "!="
        elif operator == FilterOperator.GTE:
            return ">="
        elif operator == FilterOperator.LTE:
            return "<="
        elif operator == FilterOperator.IN:
            return "IN"
        elif operator == FilterOperator.NIN:
            return "NOT IN"
        elif operator == FilterOperator.CONTAINS:
            return "@>"
        else:
            print(f"Unknown operator: {operator}, fallback to '='")
            return "="

    def _build_filter_clause(self, filter_: MetadataFilter) -> Any:
        from sqlalchemy import text

        if filter_.operator in [FilterOperator.IN, FilterOperator.NIN]:
            # Expects a single value in the metadata, and a list to compare

            # In Python, to create a tuple with a single element, you need to include a comma after the element
            # This code will correctly format the IN clause whether there is one element or multiple elements in the list:
            filter_value = ", ".join(f"'{e}'" for e in filter_.value)

            return text(
                f"metadata_->>'\"{filter_.key}\"' "
                f"{self._to_postgres_operator(filter_.operator)} "
                f"({filter_value})"
            )
        elif filter_.operator == FilterOperator.CONTAINS:
            # Expects a list stored in the metadata, and a single value to compare
            return text(
                f"metadata_::jsonb->'{filter_.key}' "
                f"{self._to_postgres_operator(filter_.operator)} "
                f"'[\"{filter_.value}\"]'"
            )
        else:
            # Check if value is a number. If so, cast the metadata value to a float
            # This is necessary because the metadata is stored as a string
            try:
                return text(
                    f"(metadata_->>'\"{filter_.key}\"')::float "
                    f"{self._to_postgres_operator(filter_.operator)} "
                    f"{float(filter_.value)}"
                )
            except ValueError:
                # If not a number, then treat it as a string
                return text(
                    f"metadata_->>'\"{filter_.key}\"' "
                    f"{self._to_postgres_operator(filter_.operator)} "
                    f"'{filter_.value}'"
                )

    def _recursively_apply_filters(self, filters: List[MetadataFilters]) -> Any:
        """
        Returns a sqlalchemy where clause.
        """
        import sqlalchemy

        sqlalchemy_conditions = {
            "or": sqlalchemy.sql.or_,
            "and": sqlalchemy.sql.and_,
        }

        if filters.condition not in sqlalchemy_conditions:
            raise ValueError(
                f"Invalid condition: {filters.condition}. "
                f"Must be one of {list(sqlalchemy_conditions.keys())}"
            )

        return sqlalchemy_conditions[filters.condition](
            *(
                (
                    self._build_filter_clause(filter_)
                    if not isinstance(filter_, MetadataFilters)
                    else self._recursively_apply_filters(filter_)
                )
                for filter_ in filters.filters
            )
        )

    def _apply_filters_and_limit(
            self,
            stmt: Select,
            limit: int,
            metadata_filters: Optional[MetadataFilters] = None,
    ) -> Any:
        if metadata_filters:
            stmt = stmt.where(  # type: ignore
                self._recursively_apply_filters(metadata_filters)
            )
        return stmt.limit(limit)  # type: ignore

    def _build_query(
            self,
            embedding: Optional[List[float]],
            limit: int = 10,
            metadata_filters: Optional[MetadataFilters] = None,
    ) -> Any:
        from sqlalchemy import select, text

        stmt = select(  # type: ignore
            self._table_class.id,
            self._table_class.node_id,
            self._table_class.text,
            self._table_class.metadata_,
            self._table_class.embedding.cosine_distance(embedding).label("distance"),
        ).order_by(text("distance asc"))

        return self._apply_filters_and_limit(stmt, limit, metadata_filters)

    def _query_with_score(
            self,
            embedding: Optional[List[float]],
            limit: int = 10,
            metadata_filters: Optional[MetadataFilters] = None,
            **kwargs: Any,
    ) -> Any:
        stmt = self._build_query(embedding, limit, metadata_filters)
        stmt_str = stmt.compile(compile_kwargs={"literal_binds": True})
        if self.debug is True:
            self._logger.debug(f"Executing query: {stmt_str}")

        session = self._client.get_session()
        result = session.execute_sql(str(stmt_str))
        self._client.release_session(session)

        return self._db_rows_to_query_result(result)

    def _db_rows_to_query_result(
            self, rows: JiuyuanResultSet
    ) -> VectorStoreQueryResult:
        nodes = []
        similarities = []
        ids = []
        if rows is None:
            return VectorStoreQueryResult(nodes=[], similarities=[], ids=[])

        for db_embedding_row in rows:
            node = metadata_dict_to_node(db_embedding_row.get_json_by_name("metadata_"))
            node.set_content(str(db_embedding_row.get_string_by_name("text")))
            similarities.append(db_embedding_row.get_double_by_name("distance"))
            ids.append(db_embedding_row.get_string_by_name("node_id"))
            nodes.append(node)

        return VectorStoreQueryResult(
            nodes=nodes,
            similarities=similarities,
            ids=ids,
        )

    def query(self, query: VectorStoreQuery, **kwargs: Any) -> VectorStoreQueryResult:
        self._initialize()
        return self._query_with_score(
            query.query_embedding,
            query.similarity_top_k,
            query.filters,
            **kwargs,
        )

    def add_nodes(self, nodes: List[BaseNode], chunk_size=300):
        session = self._client.get_session()
        session.add_text_nodes(schema_name=self._table_class.__table_args__["schema"],
                               table_name=self._table_class.__tablename__,
                               embed_dim=self._table_class.embed_vector_dim, nodes=nodes, chunk_size=chunk_size)
        self._client.release_session(session)

    def add(self, nodes: List[BaseNode], **add_kwargs: Any) -> List[str]:
        self._initialize()

        ids = [node.node_id for node in nodes]

        self.add_nodes(nodes)

        return ids

    def close(self):
        self._client.close_sessions()
