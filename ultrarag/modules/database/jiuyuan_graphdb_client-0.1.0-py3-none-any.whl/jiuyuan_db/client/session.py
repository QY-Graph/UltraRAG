import logging

from typing import Any, List
from llama_index.core.schema import BaseNode
from jiuyuan_db.jiuyuan_result_set import JiuyuanResultSet
from jiuyuan_db.model.graph import Graph
from jiuyuan_db.model.label import Label
from jiuyuan_db.model.memory_graph import MemoryGraph

logger = logging.getLogger(__name__)


class Session:
    def __init__(self, session_id, request_handler):
        self.session_id = session_id
        self.request_handler = request_handler

    def execute_query(self, graph_id, query) -> JiuyuanResultSet:
        """
        在指定图中执行 Cypher 语句。

        Args:
            : graph_id: 执行语句的图ID。
            : query: Cypher语句。

        Returns:
            : Cypher查询返回的结果。
        """
        return self.request_handler.query_client.execute_query(self.session_id, graph_id, query)

    def execute_sql(self, query) -> JiuyuanResultSet:
        """
        执行 SQL 语句。

        Args:
            : query: SQL 语句。

        Returns:
            : 语句执行的结果。
        """
        return self.request_handler.query_client.execute_sql(self.session_id, query)

    def execute_sql_update(self, query):
        self.request_handler.schema_client.execute_sql_update(self.session_id, query)
    def query_users(self) -> JiuyuanResultSet:
        """
        查询此数据库中的全部用户。

        Returns:
            : 全部用户的列表。
        """
        return self.execute_sql('SELECT * FROM pg_catalog.pg_user;')

    def query_roles(self) -> JiuyuanResultSet:
        """
        查询此数据库中的全部角色。

        Returns:
            : 全部角色的列表。
        """
        return self.execute_sql('SELECT * FROM pg_roles;')

    def get_graph(self, graph_name) -> Graph:
        """
        通过图名称查询相应的图。

        Args:
            : graph_name: 查询的图名称。

        Returns:
            : 查询到的图。
        """
        return self.request_handler.schema_client.get_graph(self.session_id, graph_name)

    def create_graph(self, graph_name, if_not_exists) -> Graph:
        """
        创建一个新图。

        Args:
            : graph_name: 创建的图名称。
            : if_not_exists: 当设置为 true 时，如果图不存在则创建，如果图存在则返回已存在的图。当设置为 false 时，如果图不存在则创建，如果图存在则创建失败。
        Returns:
            : 返回新建的图或者是已存在的图。
        """
        return self.request_handler.schema_client.create_graph(self.session_id, graph_name=graph_name,
                                                               if_not_exists=if_not_exists)

    def drop_graph(self, graph_name):
        """
        删除一个已存在的图。

        Args:
            : graph_name: 删除的图名称。

        """
        self.request_handler.schema_client.drop_graph(self.session_id, graph_name)

    def get_all_graphs(self) -> JiuyuanResultSet:
        """
        查询所有图。

        Returns:
            : 全部创建的图。
        """
        return self.execute_sql(query="select graphid, name from ag_graph;")

    def create_vertex_label(self, graph_id, label) -> Label:
        """
        在图中创建新的点标签。

        Args:
            : graph_id: 新标签所在的图id。
            : label: 创建的点标签名。

        Returns:
            : 新创建的点标签。
        """
        return self.request_handler.schema_client.create_vertex_label(self.session_id, graph_id, label)

    def create_edge_label(self, graph_id, label) -> Label:
        """
        在图中创建新的边标签。

        Args:
            : graph_id: 新标签所在的图id。
            : label: 创建的边标签名。

        Returns:
            : 新创建的边标签。
        """
        return self.request_handler.schema_client.create_edge_label(self.session_id, graph_id, label)

    def get_all_labels(self) -> JiuyuanResultSet:
        """
        查询全部标签。

        Returns:
            : 全部标签。
        """
        return self.execute_sql(f'SELECT name, graph, kind FROM ag_catalog.ag_label '
                                f'where name!=\'_ag_label_edge\' and name!=\'_ag_label_vertex\';')

    def get_labels(self, graph_id) -> JiuyuanResultSet:
        """
        查询指定图的标签。

        Args:
            : graph_id: 图id。

        Returns:
            : 指定图的标签。
        """
        return self.execute_sql(f'SELECT name, graph, kind FROM ag_catalog.ag_label '
                                f'where name!=\'_ag_label_edge\' and name!=\'_ag_label_vertex\' '
                                f'and graph = {graph_id};')

    def load_vertices_from_file(self, graph_id, label_name, data_path):
        """
        将数据路径下的点数据导入到对应的图中。

        Args:
            : graph_id: 导入数据的图id。
            : label_name: 导入数据的点标签名称。
            : data_path: 点数据所在路径。
        """
        self.request_handler.schema_client.load_vertices_from_file(
            self.session_id, graph_id, label_name, data_path)

    def load_edges_from_file(self, graph_id, label_name, data_path):
        """
        将数据路径下的边数据导入到对应的图中。

        Args:
            : graph_id: 导入数据的图id。
            : label_name: 导入数据的边标签名称。
            : data_path: 边数据所在路径。
        """
        self.request_handler.schema_client.load_edges_from_file(
            self.session_id, graph_id, label_name, data_path)

    def project_graph(self, graph_id, filters) -> MemoryGraph:
        """
        从指定图中提取一张内存子图并存储到文件中。

        Args:
            : graph_id: 被提取的原图ID。
            : filters: 内存子图过滤条件。

        Returns:
            : 从指定图中提取的内存子图。
        """
        return self.request_handler.schema_client.project_graph(self.session_id, graph_id, filters)

    # TODO: logging and exception
    def run_analytic_job(self, memory_graph_id, config, return_result) -> JiuyuanResultSet:
        """
        基于指定的内存子图执行图分析任务。

        Args:
            : memory_graph_id: 执行图分析任务的内存子图。
            : config: 图分析任务所需的配置参数。
            : return_result: 是否返回分析结果。

        Returns:
            : 图分析任务的执行结果。
        """
        try:
            return self.request_handler.query_client.run_analytic_job(self.session_id, memory_graph_id, config,
                                                                      return_result)
        except Exception as e:
            logger.error(f'Failed to run analytic job: {e}')
            return None

    def run_graph_algorithm(self, memory_graph_id, algorithm_name, args_dict, return_result) -> JiuyuanResultSet:
        """
        基于指定的内存子图执行图算法。

        Args:
            : memory_graph_id: 执行图分析任务的内存子图。
            : algorithm_name: 图算法名称。
            : args_dict: 图算法参数。
            : return_result: 是否返回分析结果。

        Returns:
            : 图分析任务的执行结果。
        """
        try:
            return self.request_handler.query_client.run_graph_algorithm(self.session_id, memory_graph_id, algorithm_name,args_dict,
                                                                      return_result)
        except Exception as e:
            logger.error(f'Failed to run graph algorithm : {e}')
            return None

    def export_graph_label(self, graph_name, label, output_path, entity_type, with_header):
        """
        导出图中特定标签中的数据。

        Args:
            : graph_name: 导出的图名称。
            : label: 导出的标签名。
            : output_path: 导出的路径。
            : entity_type: 导出的数据类型(边、点)。
            : with_header: 导出文件是否需要表头。
        """
        logger.debug(f'Exporting graph {graph_name} label {label} entity_type {entity_type} '
                     f'to {output_path} with_header {with_header}')
        self.request_handler.schema_client.export_graph_label(self.session_id, graph_name, label, output_path,
                                                              entity_type, with_header)

    def create_task_graph(self, graph_name):
        """
        创建一个新图。

        Args:
            : graph_name: 创建的图名称。
        Returns:
            : 返回新建的图或者是已存在的图。
        """
        self.request_handler.schema_client.execute_sql_update(self.session_id,
                                                              query=f'CREATE TABLE IF NOT EXISTS {graph_name} (base_vertex_id varchar(256), task_vertex_label varchar(256), task_vertex_id varchar(256), PRIMARY KEY(base_vertex_id));')
        return self.request_handler.schema_client.create_graph(self.session_id, graph_name=graph_name,
                                                               if_not_exists=False)

    def add_text_nodes(self, schema_name, table_name, embed_dim, nodes: List[BaseNode], chunk_size):
        self.request_handler.query_client.add_text_nodes(schema_name, table_name, embed_dim, self.session_id, nodes, chunk_size)

