import json
import logging

from typing import Any, List
from llama_index.core.schema import BaseNode
from jiuyuan_db import jiuyuan_result_set
from jiuyuan_db.client.abstract_client import AbstractClient
from jiuyuan_db.jiuyuan_exception import JiuyuanException
from jiuyuan_db.jiuyuan_result_set import JiuyuanResultSet
from jiuyuan_db.jiuyuan_result_set import merge_jiuyuan_result_set
from jiuyuan_db.rpc import query_service_pb2, query_service_pb2_grpc
from jiuyuan_db.util import node_to_metadata_dict
from llama_index.core.schema import BaseNode, MetadataMode
from google.protobuf.struct_pb2 import Struct

logger = logging.getLogger(__name__)


def stream_response_handler(response_iterator):
    result_set_list = []
    for response in response_iterator:
        result_set_list.append(jiuyuan_result_set.from_proto(response.result))
    return merge_jiuyuan_result_set(result_set_list)


class QueryServiceClient(AbstractClient):
    def __init__(self, host, port):
        super().__init__(host, port)
        self.stub = query_service_pb2_grpc.JiuyuanGraphDatabaseQueryServiceStub(self.channel)

    def execute_query(self, session_id, graph_id, query) -> JiuyuanResultSet:
        """
        在指定图中执行 Cypher 语句。

        Args:
            : session_id: 会话ID。
            : graph_id: 执行语句的图ID。
            : query: Cypher语句。

        Returns:
            : Cypher查询返回的结果。
        """
        response = self.stub.ExecuteCypher(query_service_pb2.CypherRequest(
            session_id=session_id, graph_id=graph_id, cypher_query=query))
        result_set_list = []
        for res in response:
            if res.success:
                logger.debug("Execute Cypher: ", query, " successfully")
                result_set_list.append(jiuyuan_result_set.from_proto(res.result))
            else:
                raise JiuyuanException(res.error_message)
        return merge_jiuyuan_result_set(result_set_list)

    def execute_sql(self, session_id, query) -> JiuyuanResultSet:
        """
        执行 SQL 语句。

        Args:
            : session_id: 会话ID。
            : query: SQL 语句。

        Returns:
            : 语句执行的结果。
        """
        request = query_service_pb2.SqlRequest(
            session_id=session_id, sql_query=query)
        logger.debug("Message size is %s bytes for Sql query: %s", str(request.ByteSize()), query)
        response = self.stub.ExecuteSql(request)
        result_set_list = []
        for res in response:
            if res.success:
                result_set_list.append(jiuyuan_result_set.from_proto(res.result))
            else:
                raise JiuyuanException(res.error_message)
        return merge_jiuyuan_result_set(result_set_list)

    def run_analytic_job(self, session_id, memory_graph_id, config, return_result) -> JiuyuanResultSet:
        """
        基于指定的内存子图执行图分析任务。

        Args:
            : session_id: 会话ID。
            : memory_graph_id: 执行图分析任务的内存子图。
            : config: 图分析任务所需的配置参数。
            : return_result: 是否返回分析结果。

        Returns:
            : 图分析任务的执行结果。
        """
        response = self.stub.RunAnalyticJob(query_service_pb2.AnalyticRequest(
            session_id=session_id,
            memory_graph_id=memory_graph_id,
            config=config.to_dict(),
            return_result=return_result))
        return stream_response_handler(response)
    
    def run_graph_algorithm(self,session_id, memory_graph_id, algorithm_name,args_dict,
                                                                      return_result):
        """
        基于指定的内存子图执行图算法。

        Args:
            : memory_graph_id: 执行图分析任务的内存子图。
            : algorithm_name: 图算法名称。
            : args_dict: 图算法参数。
            : return_result: 是否返回分析结果。

        Returns:
            : 图分析任务的执行结果。
        """
        response = self.stub.RunGraphAlgorithm(query_service_pb2.GraphAlgorithmRequest(
                session_id=session_id,
                algorithmName=algorithm_name,
                memoryGraphIds=memory_graph_id,
                args=args_dict,
                return_result=return_result
            ))
        result_set_list = []
        for response_item in response:
            result_set_list.append(response_item.result)

        print(result_set_list)
        
        return result_set_list

    def add_text_nodes(self, schema_name, table_name, embed_dim, session_id, nodes: List[BaseNode], chunk_size):
        # create a list of requests where each request contains a sublist of nodes

        header = query_service_pb2.AddTextNodeHeader(
            session_id=session_id, schemaName=schema_name, tableName=table_name, embedDim=embed_dim)
        header_request = query_service_pb2.AddTextNodeRequest(header = header)
        logger.debug("AddTextNodeHeader message size is %s bytes", str(header_request.ByteSize()))
        requests = []
        for i in range(0, len(nodes), chunk_size):
            chunk = nodes[i:i + chunk_size]
            text_nodes = []
            for node in chunk:
                node_id = node.node_id
                embedding = node.get_embedding()
                text = node.get_content(metadata_mode=MetadataMode.NONE)
                metadata_ = node_to_metadata_dict(
                    node,
                    remove_text=True,
                    flat_metadata=False,
                )
                metadata_struct = Struct()
                metadata_struct.update(metadata_)
                text_node = query_service_pb2.SingleTextNode(
                    nodeId=node_id,
                    text=text,
                    metadata=metadata_struct,
                    vector=embedding
                )
                text_nodes.append(text_node)

            payload = query_service_pb2.AddTextNodePayload(textNodes=text_nodes)
            payload_request = query_service_pb2.AddTextNodeRequest(payload = payload)
            logger.debug("Add %s nodes of size %s bytes", len(text_nodes),str(payload_request.ByteSize()))
            requests.append(payload_request)
        response = self.stub.AddTextNode(iter([header_request] + requests))
