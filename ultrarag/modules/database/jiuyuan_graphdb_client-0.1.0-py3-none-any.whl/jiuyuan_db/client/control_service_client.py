import logging

from jiuyuan_db.client.abstract_client import AbstractClient
from jiuyuan_db.jiuyuan_exception import JiuyuanException
from jiuyuan_db.rpc import control_service_pb2, control_service_pb2_grpc

logger = logging.getLogger(__name__)


class ControlServiceClient(AbstractClient):
    def __init__(self, host, port, user, password, database_name):
        super().__init__(host, port)
        self.stub = control_service_pb2_grpc.JiuyuanGraphDatabaseControlServiceStub(self.channel)
        self.user = user
        self.password = password
        self.database_name = database_name

    def create_session(self) -> int:
        """
        创建会话。

        Returns:
            : 创建成功的会话ID。
        """
        response = self.stub.CreateSession(control_service_pb2.CreateSessionRequest(
            user=self.user, password=self.password, database_name=self.database_name))
        if response.success:
            logger.debug("Create session successfully, session id: %s", response.session_id)
            return response.session_id
        else:
            raise JiuyuanException(response.error_message)

    def drop_session(self, session_id):
        """
        删除指定ID的会话。

        Args:
            : session_id: 会话ID。

        """
        response = self.stub.DropSession(control_service_pb2.DropSessionRequest(session_id=session_id))
        if response.success:
            logger.debug("Drop session successfully, session id: %s", session_id)
        else:
            raise JiuyuanException(response.error_message)
