import logging
import threading
from queue import Queue

from jiuyuan_db.client.control_service_client import ControlServiceClient
from jiuyuan_db.client.query_service_client import QueryServiceClient
from jiuyuan_db.client.schema_service_client import SchemaServiceClient
from jiuyuan_db.client.session import Session
from jiuyuan_db.jiuyuan_exception import JiuyuanException

logger = logging.getLogger(__name__)


class RequestHandler:
    def __init__(self, host, port, user, password, database_name):
        self.host = host
        self.port = port
        self.user = user
        self.password = password
        self.control_client = ControlServiceClient(host=host, port=port, user=user, password=password,
                                                   database_name=database_name)
        self.query_client = QueryServiceClient(host=host, port=port)
        self.schema_client = SchemaServiceClient(host=host, port=port)


class JiuyuanClient:
    DEFAULT_POOL_SIZE = 30

    def __init__(self, host, port, user, password, database_name, max_size=DEFAULT_POOL_SIZE):
        self.request_handler = RequestHandler(host, port, user, password, database_name)

        self.pool_size = max_size
        self.pool = Queue(self.pool_size)
        self.semaphore = threading.Semaphore(self.pool_size)

    def get_session(self) -> Session:
        """
        获取一个连接至指定数据库的会话实例，若不存在可用的实例则创建一个新会话。

        Returns:
            : 一个会话实例。
        """
        self.semaphore.acquire()
        if not self.pool.empty():
            session = self.pool.get()
            return session
        else:
            session_id = self.request_handler.control_client.create_session()
            if session_id is None:
                self.semaphore.release()
                raise JiuyuanException("Get session failed, no available session")
            return Session(session_id, self.request_handler)

    def release_session(self, session):
        """
        释放当前会话，会将此会话放到会话池中供后续分配使用。

        Args:
            : session: 需要释放的会话对象。
        """
        self.pool.put(session)
        self.semaphore.release()
        logger.debug("Release session successfully, session id: %s", session.session_id)

    def close_sessions(self):
        """
        关闭客户端的全部会话。
        """
        while not self.pool.empty():
            self.semaphore.acquire()
            session = self.pool.get()
            assert session is not None, "session in pool cannot be None"
            self.request_handler.control_client.drop_session(session.session_id)
            self.semaphore.release()
            logger.debug("Close session successfully, session id: %s", session.session_id)
        logger.info("Close all sessions successfully")
