import json
from llama_index.core.schema import BaseNode, MetadataMode
from llama_index.core.vector_stores.utils import (
    metadata_dict_to_node,
    node_to_metadata_dict,
)
def node_to_dict(self, node: BaseNode) -> dict:
    node_id = node.node_id
    embedding = node.get_embedding()
    text = node.get_content(metadata_mode=MetadataMode.NONE)
    metadata_ = node_to_metadata_dict(
        node,
        remove_text=True,
        flat_metadata=False,
    )
    return {
        "text": text,
        "metadata_": json.dumps(metadata_),
        "node_id": node_id,
        "embedding": embedding
    }