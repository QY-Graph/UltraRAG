from jiuyuan_db import control_service_pb2
from jiuyuan_db import control_service_pb2_grpc
from jiuyuan_db import AbstractClient

class ControlServiceClient(AbstractClient):
    def __init__(self, host, port):
        super().__init__(host, port)
        self.stub = control_service_pb2_grpc.JiuyuanGraphDatabaseControlServiceStub(self.channel)

    def create_session(self):
        response = self.stub.CreateSession(control_service_pb2.CreateSessionRequest())
        return response.session_id

