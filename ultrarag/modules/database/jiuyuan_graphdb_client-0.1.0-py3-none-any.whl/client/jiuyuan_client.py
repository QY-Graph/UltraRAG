from jiuyuan_db import control_client
from jiuyuan_db import query_client
from jiuyuan_db import schema_client
class JiuyuanClient:
    def __init__(self, host, port):
        self.host = host
        self.port = port
        self.control_client = control_client.ControlServiceClient(host=host, port=port)
        self.query_client = query_client.QueryServiceClient(host=host, port=port)
        self.schema_client = schema_client.SchemaServiceClient(host=host, port=port)
        # self.session_id = self.control_client.create_session()

    def execute_query(self, graph_id, query):
        return self.query_client.execute_query(self.session_id, graph_id, query)

    def get_graph(self, graph_name):
        return self.schema_client.get_graph(self.session_id, graph_name)

    def project_graph(self, graph_id, filters):
        return self.schema_client.project_graph(self.session_id, graph_id, filters)

    def run_analytic_job(self, memory_graph_id, config, return_result):
        return self.query_client.run_analytic_job(self.session_id, memory_graph_id, config, return_result)