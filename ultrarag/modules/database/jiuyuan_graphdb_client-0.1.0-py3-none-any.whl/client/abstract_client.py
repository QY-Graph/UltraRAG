import grpc
class AbstractClient:
    def __init__(self, host, port):
        self.host = host
        self.port = port
        self.channel = grpc.insecure_channel(f'{host}:{port}',
                                             options=[('grpc.enable_http_proxy', 0)])