VERTEX_TYPE = "VERTEX"
EDGE_TYPE = "EDGE"
class SingleFilter:
    def __init__(self, entity_type, label_name):
        self.type = entity_type
        self.labelName = label_name

    def to_dict(self):
        return {
            "type": self.type,
            "labelName": self.labelName
        }

class MemoryGraphFilter:
    def __init__(self, filters):
        self.filters = filters

    def add_filter(self, filter):
        self.filters.append(filter)

    def to_dict(self):
        return {
            "filters": [filter.to_dict() for filter in self.filters]
        }