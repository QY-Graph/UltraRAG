from . import schema_service_pb2_grpc, schema_service_pb2
from .. import abstract_client

class SchemaServiceClient(abstract_client.AbstractClient):
    def __init__(self, host, port):
        super().__init__(host, port)
        self.stub = schema_service_pb2_grpc.JiuyuanGraphDatabaseSchemaServiceStub(self.channel)

    def get_graph(self, session_id, graph_name):
        return self.stub.GetGraph(schema_service_pb2.GetGraphRequest(
            session_id=session_id, graph_name=graph_name))

    def project_graph(self, session_id, graph_id, filters):
        return self.stub.Project(schema_service_pb2.ProjectRequest(
            session_id=session_id, graph_id=graph_id, filters=filters.to_dict()))