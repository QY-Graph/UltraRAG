import logging
import age
from typing import List, Dict
from jiuyuan_db.model.entity import Vertex, Edge, Path

logger = logging.getLogger("JiuyuanResultSet")

class JiuyuanResultSet:
    def __init__(self, column_names = [], result_list =[]):
        self.column_names = column_names
        self.result_list = result_list
        # column index starts from 1
        self.column_name_index = {
            column_name: i + 1 for i, column_name in enumerate(column_names)}
        self.next_position = 0


    def get_column_count(self) -> int:
        return len(self.column_names)

    def next(self) -> bool:
        self.next_position += 1
        return self.next_position <= len(self.result_list)

    def get_object(self, column_index: int):
        if self.next_position == 0 or self.next_position > len(self.result_list):
            logger.error("Get invalid result")
            return None
        if not 0 < column_index <= len(self.column_names):
            logger.error("Get invalid column")
            return None
        return self.result_list[self.next_position - 1][column_index - 1]

    def get_object_by_name(self, column_name: str):
        column_index = self.column_name_index.get(column_name)
        print('column: ' + str(column_index) + ' ' + column_name)
        return self.get_object(column_index)

    def get_string(self, column_index: int) -> str:
        return str(self.get_object(column_index))

    def get_string_by_name(self, column_name: str) -> str:
        return str(self.get_object_by_name(column_name))

    def get_int(self, column_index: int) -> int:
        return int(self.get_object(column_index))

    def get_int_by_name(self, column_name: str) -> int:
        return int(self.get_object_by_name(column_name))

    def get_long(self, column_index: int) -> int:
        return int(self.get_object(column_index))

    def get_long_by_name(self, column_name: str) -> int:
        return int(self.get_object_by_name(column_name))

    def get_double(self, column_index: int) -> float:
        return float(self.get_object(column_index))

    def get_double_by_name(self, column_name: str) -> float:
        return float(self.get_object_by_name(column_name))

    def get_result_list(self) -> List[Dict]:
        return self.result_list

    def get_column_names(self) -> List[str]:
        return self.column_names

    def get_column_name_index(self) -> Dict[str, int]:
        return self.column_name_index

    def get_vertex(self, column_index: int):
        age_vertex = age.parseAgeValue(self.get_string(column_index))
        return Vertex(age_vertex.id, age_vertex.label, age_vertex.properties)


    def get_edge(self, column_index: int):
        age_edge = age.parseAgeValue(self.get_string(column_index))
        return Edge(age_edge.id, age_edge.label, age_edge.start_id, age_edge.end_id, age_edge.properties)

    def get_path(self, column_index: int):
        age_path = age.parseAgeValue(self.get_string(column_index))
        return Path(age_path.entities)

def from_proto(proto_message):
    column_names = proto_message.column_names
    result_list = []
    for proto_record in proto_message.result_list:
        jy_record = []
        for field in proto_record.record:
            jy_record.append(field)
        result_list.append(jy_record)
    return JiuyuanResultSet(column_names, result_list)
