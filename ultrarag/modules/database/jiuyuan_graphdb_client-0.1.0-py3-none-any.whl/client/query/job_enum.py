from enum import Enum

class AnalyticJobEnum(Enum):
    PAGERANK = "pagerank"
    SSSP = "sssp"
    BFS = "bfs"
    ALL_PAIR_SSSP = "all_pair_sssp"
    CC = "cc"
    DC = "dc"
    HITS = "hits"
    KCORE = "kcore"
    KHOP = "khop"
    MSSP = "mssp"
    SSNP = "ssnp"
    SSWP = "sswp"
    TREE_STAT = "tree_stat"
    WCC = "wcc"
    WCC_UNDIRECT = "wcc_undirect"
    WPAGERANK = "wpagerank"
