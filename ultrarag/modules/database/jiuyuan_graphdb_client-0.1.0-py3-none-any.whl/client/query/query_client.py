from jiuyuan_db import query_service_pb2_grpc, query_service_pb2
from jiuyuan_db import jiuyuan_result_set, abstract_client


class QueryServiceClient(abstract_client.AbstractClient):
    def __init__(self, host, port):
        super().__init__(host, port)
        self.stub = query_service_pb2_grpc.JiuyuanGraphDatabaseQueryServiceStub(self.channel)

    def execute_query(self, session_id, graph_id, query):
        response = self.stub.ExecuteCypher(query_service_pb2.CypherRequest(
            session_id = session_id, graph_id = graph_id, cypher_query = query))
        return jiuyuan_result_set.from_proto(response.result)

    def run_analytic_job(self, session_id, memory_graph_id, config, return_result):

        response = self.stub.RunAnalyticJob(query_service_pb2.AnalyticRequest(
            session_id = session_id,
            memory_graph_id = memory_graph_id,
            config = config.to_dict(),
            return_result = return_result))
        return jiuyuan_result_set.from_proto(response.result)