import logging
from typing import List
from .job_enum import AnalyticJobEnum

logger = logging.getLogger(__name__)


class AnalyticJobConfigConstant:
    LOAD_CONCURRENCY = "load_concurrency"
    COROUTINES_CONCURRENCY = "coroutines_concurrency"
    REDUCER_CONCURRENCY = "reducer_concurrency"
    SPLIT_CONCURRENCY = "split_concurrency"


class AnalyticJobConfig:
    def __init__(self, hosts: List[str] = [], port: str = "", job_name: str = "", args=None):
        self._hosts = hosts
        self._port = port
        self._job_name = job_name
        self._args = args

    @property
    def hosts(self):
        return self._hosts

    @property
    def job_name(self):
        return self._job_name

    @property
    def port(self):
        return self._port

    @property
    def args(self):
        return self._args

    @hosts.setter
    def hosts(self, hosts: List[str]):
        self._hosts = hosts

    @port.setter
    def port(self, port: str):
        self._port = port

    @job_name.setter
    def job_name(self, job_name: str):
        self._job_name = job_name

    @args.setter
    def args(self, value):
        self._args = value

    def add_arg(self, key: str, value: str):
        self._args[key] = value

    def validate_config(self) -> bool:
        algs = {alg.value for alg in AnalyticJobEnum}
        if self._job_name not in algs:
            logger.error(f"Cannot find algorithm: {self._job_name}")
            return False
        return True

    def to_dict(self):
        config = {}
        config['job_name'] = self._job_name
        config['hosts'] = self._hosts
        config['port'] = self._port
        config['parameters'] = self._args
        return config
