import logging

import grpc
import threading
from queue import Queue

from jiuyuan_db.rpc import control_service_pb2, control_service_pb2_grpc
from jiuyuan_db.rpc import query_service_pb2, query_service_pb2_grpc
from jiuyuan_db.rpc import schema_service_pb2, schema_service_pb2_grpc
from jiuyuan_db import jiuyuan_result_set
from jiuyuan_db.jiuyuan_result_set import JiuyuanResultSet
from jiuyuan_db.model.graph import Graph
from jiuyuan_db.model.label import Label
from jiuyuan_db.model.entity import EntityType
from jiuyuan_db.model.memory_graph import MemoryGraph
from jiuyuan_db.jiuyuan_result_set import merge_jiuyuan_result_set
from jiuyuan_db.jiuyuan_exception import JiuyuanException

logger = logging.getLogger(__name__)


class Session:
    def __init__(self, session_id, request_handler):
        self.session_id = session_id
        self.request_handler = request_handler

    def execute_query(self, graph_id, query) -> JiuyuanResultSet:
        """
        在指定图中执行 Cypher 语句。
        
        Args:
            : graph_id: 执行语句的图ID。
            : query: Cypher语句。
        
        Returns:
            : Cypher查询返回的结果。
        """
        return self.request_handler.query_client.execute_query(self.session_id, graph_id, query)

    def execute_sql(self, query) -> JiuyuanResultSet:
        """
        执行 SQL 语句。
        
        Args:
            : query: SQL 语句。
        
        Returns:
            : 语句执行的结果。
        """
        return self.request_handler.query_client.execute_sql(self.session_id, query)

    def query_users(self) -> JiuyuanResultSet:
        """
        查询此数据库中的全部用户。
        
        Returns:
            : 全部用户的列表。
        """
        return self.execute_sql('SELECT * FROM pg_catalog.pg_user;')

    def query_roles(self) -> JiuyuanResultSet:
        """
        查询此数据库中的全部角色。
        
        Returns:
            : 全部角色的列表。
        """
        return self.execute_sql('SELECT * FROM pg_roles;')

    def get_graph(self, graph_name) -> Graph:
        """
        通过图名称查询相应的图。

        Args:
            : graph_name: 查询的图名称。
        
        Returns:
            : 查询到的图。
        """
        return self.request_handler.schema_client.get_graph(self.session_id, graph_name)

    def create_graph(self, graph_name, if_not_exists) -> Graph:
        """
        创建一个新图。

        Args:
            : graph_name: 创建的图名称。
            : if_not_exists: 当设置为 true 时，如果图不存在则创建，如果图存在则返回已存在的图。当设置为 false 时，如果图不存在则创建，如果图存在则创建失败。
        Returns:
            : 返回新建的图或者是已存在的图。
        """
        return self.request_handler.schema_client.create_graph(self.session_id, graph_name=graph_name,
                                                                   if_not_exists=if_not_exists)
    
    def drop_graph(self, graph_name):
        """
        删除一个已存在的图。

        Args:
            : graph_name: 删除的图名称。

        """
        self.request_handler.schema_client.drop_graph(self.session_id, graph_name)

    def get_all_graphs(self) -> JiuyuanResultSet:
        """
        查询所有图。

        Returns:
            : 全部创建的图。
        """
        return self.execute_sql(query="select graphid, name from ag_graph;")

    def create_vertex_label(self, graph_id, label) -> Label:
        """
        在图中创建新的点标签。

        Args:
            : graph_id: 新标签所在的图id。
            : label: 创建的点标签名。

        Returns:
            : 新创建的点标签。
        """
        return self.request_handler.schema_client.create_vertex_label(self.session_id, graph_id, label)

    def create_edge_label(self, graph_id, label) -> Label:
        """
        在图中创建新的边标签。

        Args:
            : graph_id: 新标签所在的图id。
            : label: 创建的边标签名。

        Returns:
            : 新创建的边标签。
        """
        return self.request_handler.schema_client.create_edge_label(self.session_id, graph_id, label)


    def get_all_labels(self) -> JiuyuanResultSet:
        """
        查询全部标签。

        Returns:
            : 全部标签。
        """
        return self.execute_sql(f'SELECT name, graph, kind FROM ag_catalog.ag_label '
                                f'where name!=\'_ag_label_edge\' and name!=\'_ag_label_vertex\';')

    def get_labels(self, graph_id) -> JiuyuanResultSet:
        """
        查询指定图的标签。

        Args:
            : graph_id: 图id。

        Returns:
            : 指定图的标签。
        """
        return self.execute_sql(f'SELECT name, graph, kind FROM ag_catalog.ag_label '
                                f'where name!=\'_ag_label_edge\' and name!=\'_ag_label_vertex\' '
                                f'and graph = {graph_id};')

    def load_vertices_from_file(self, graph_id, label_name, data_path):
        """
        将数据路径下的点数据导入到对应的图中。

        Args:
            : graph_id: 导入数据的图id。
            : label_name: 导入数据的点标签名称。
            : data_path: 点数据所在路径。
        """
        self.request_handler.schema_client.load_vertices_from_file(
                self.session_id, graph_id, label_name, data_path)

    def load_edges_from_file(self, graph_id, label_name, data_path):
        """
        将数据路径下的边数据导入到对应的图中。

        Args:
            : graph_id: 导入数据的图id。
            : label_name: 导入数据的边标签名称。
            : data_path: 边数据所在路径。
        """
        self.request_handler.schema_client.load_edges_from_file(
                self.session_id, graph_id, label_name, data_path)
    

    def project_graph(self, graph_id, filters) -> MemoryGraph:
        """
        从指定图中提取一张内存子图并存储到文件中。

        Args:
            : graph_id: 被提取的原图ID。
            : filters: 内存子图过滤条件。

        Returns:
            : 从指定图中提取的内存子图。
        """
        return self.request_handler.schema_client.project_graph(self.session_id, graph_id, filters)

    # TODO: logging and exception
    def run_analytic_job(self, memory_graph_id, config, return_result) -> JiuyuanResultSet:
        """
        基于指定的内存子图执行图分析任务。

        Args:
            : memory_graph_id: 执行图分析任务的内存子图。
            : config: 图分析任务所需的配置参数。
            : return_result: 是否返回分析结果。

        Returns:
            : 图分析任务的执行结果。
        """
        try:
            return self.request_handler.query_client.run_analytic_job(self.session_id, memory_graph_id, config,
                                                                  return_result)
        except Exception as e:
            logger.error(f'Failed to run analytic job: {e}')
            return None

    def export_graph_label(self, graph_name, label, output_path, entity_type, with_header):
        """
        导出图中特定标签中的数据。

        Args:
            : graph_name: 导出的图名称。
            : label: 导出的标签名。
            : output_path: 导出的路径。
            : entity_type: 导出的数据类型(边、点)。
            : with_header: 导出文件是否需要表头。
        """
        logger.debug(f'Exporting graph {graph_name} label {label} entity_type {entity_type} '
                    f'to {output_path} with_header {with_header}')
        self.request_handler.schema_client.export_graph_label(self.session_id, graph_name, label, output_path,
                                                              entity_type, with_header)

class AbstractClient:
    def __init__(self, host, port):
        self.host = host
        self.port = port
        self.channel = grpc.insecure_channel(f'{host}:{port}',
                                             options=[('grpc.enable_http_proxy', 0)])


class ControlServiceClient(AbstractClient):
    def __init__(self, host, port, user, password, database_name):
        super().__init__(host, port)
        self.stub = control_service_pb2_grpc.JiuyuanGraphDatabaseControlServiceStub(self.channel)
        self.user = user
        self.password = password
        self.database_name = database_name

    def create_session(self) -> int:
        """
        创建会话。

        Returns:
            : 创建成功的会话ID。
        """
        response = self.stub.CreateSession(control_service_pb2.CreateSessionRequest(
            user=self.user, password=self.password, database_name=self.database_name))
        if response.success:
            logger.debug("Create session successfully, session id: ", response.session_id)
            return response.session_id
        else:
            raise JiuyuanException(response.error_message)

    def drop_session(self, session_id):
        """
        删除指定ID的会话。

        Args:
            : session_id: 会话ID。

        """
        response = self.stub.DropSession(control_service_pb2.DropSessionRequest(session_id=session_id))
        if response.success:
            logger.debug("Drop session successfully, session id: ", session_id)
        else:
            raise JiuyuanException(response.error_message)


def stream_response_handler(response_iterator):
    result_set_list = []
    for response in response_iterator:
        result_set_list.append(jiuyuan_result_set.from_proto(response.result))
    return merge_jiuyuan_result_set(result_set_list)


class QueryServiceClient(AbstractClient):
    def __init__(self, host, port):
        super().__init__(host, port)
        self.stub = query_service_pb2_grpc.JiuyuanGraphDatabaseQueryServiceStub(self.channel)

    def execute_query(self, session_id, graph_id, query) -> JiuyuanResultSet:
        """
        在指定图中执行 Cypher 语句。
        
        Args:
            : session_id: 会话ID。
            : graph_id: 执行语句的图ID。
            : query: Cypher语句。
        
        Returns:
            : Cypher查询返回的结果。
        """
        response = self.stub.ExecuteCypher(query_service_pb2.CypherRequest(
            session_id=session_id, graph_id=graph_id, cypher_query=query))
        result_set_list = []
        for res in response:
            if res.success:
                logger.debug("Execute Cypher: ", query, " successfully")
                result_set_list.append(jiuyuan_result_set.from_proto(res.result))
            else:
                raise JiuyuanException(res.error_message)
        return merge_jiuyuan_result_set(result_set_list)    

    def execute_sql(self, session_id, query) -> JiuyuanResultSet:
        """
        执行 SQL 语句。
        
        Args:
            : session_id: 会话ID。
            : query: SQL 语句。
        
        Returns:
            : 语句执行的结果。
        """
        request = query_service_pb2.SqlRequest(
            session_id=session_id, sql_query=query)
        logger.info("Message size: %s", str(request.ByteSize()))
        response = self.stub.ExecuteSql(request)
        result_set_list = []
        for res in response:
            if res.success:
                logger.debug("Execute Cypher: ", query, " successfully")
                result_set_list.append(jiuyuan_result_set.from_proto(res.result))
            else:
                raise JiuyuanException(res.error_message)
        return merge_jiuyuan_result_set(result_set_list)    

    def run_analytic_job(self, session_id, memory_graph_id, config, return_result) -> JiuyuanResultSet:
        """
        基于指定的内存子图执行图分析任务。

        Args:
            : session_id: 会话ID。
            : memory_graph_id: 执行图分析任务的内存子图。
            : config: 图分析任务所需的配置参数。
            : return_result: 是否返回分析结果。

        Returns:
            : 图分析任务的执行结果。
        """
        response = self.stub.RunAnalyticJob(query_service_pb2.AnalyticRequest(
            session_id=session_id,
            memory_graph_id=memory_graph_id,
            config=config.to_dict(),
            return_result=return_result))
        return stream_response_handler(response)


class SchemaServiceClient(AbstractClient):
    def __init__(self, host, port):
        super().__init__(host, port)
        self.stub = schema_service_pb2_grpc.JiuyuanGraphDatabaseSchemaServiceStub(self.channel)

    def create_graph(self, session_id, graph_name, if_not_exists) -> Graph:
        """
        创建一个新图。

        Args:
            : session_id: 会话ID。
            : graph_name: 创建的图名称。
            : if_not_exists: 当设置为 true 时，如果图不存在则创建，如果图存在则返回已存在的图。当设置为 false 时，如果图不存在则创建，如果图存在则创建失败。
        Returns:
            : 返回新建的图或者是已存在的图。
        """
        response = self.stub.CreateGraph(schema_service_pb2.CreateGraphRequest(
            session_id=session_id, graph_name=graph_name, if_not_exists=if_not_exists))
        if response.success:
            logger.debug("Create graph: " + graph_name + " successfully")
            return Graph(graph_name=response.graph_name, graph_id=response.graph_id)
        else:
            raise JiuyuanException(response.error_message)
        
    def drop_graph(self, session_id, graph_name):
        """
        删除一个已存在的图。

        Args:
            : session_id: 会话ID。
            : graph_name: 删除的图名称。

        """
        response = self.stub.DropGraph(schema_service_pb2.DropGraphRequest(session_id=session_id,
                                                                graphName=graph_name))
        if response.success:
            logger.debug("Drop graph: " + graph_name + " successfully")
        else:
            raise JiuyuanException(response.error_message)

    def get_graph(self, session_id, graph_name) -> Graph:
        """
        通过图名称查询相应的图。

        Args:
            : session_id: 会话ID。
            : graph_name: 查询的图名称。
        
        Returns:
            : 查询到的图。
        """
        response = self.stub.GetGraph(schema_service_pb2.GetGraphRequest(
            session_id=session_id, graph_name=graph_name))
        if response.success:
            logger.debug("Get graph: " + graph_name + " successfully")
            return Graph(graph_name=response.graph_name, graph_id=response.graph_id)
        else:
            raise JiuyuanException(response.error_message)

    def create_vertex_label(self, session_id, graph_id, label_name, if_not_exists=True) -> Label:
        """
        在图中创建新的点标签。

        Args:
            : session_id: 会话ID。
            : graph_id:  新标签所在的图id。
            : label_name: 创建的点标签名。
            : if_not_exists: 当设置为 true 时，如果标签不存在则创建新标签，如果标签存在则返回已存在的标签。当设置为 false 时，如果标签不存在则创建新标签，如果标签存在则创建失败。

        Returns:
            : 新创建的点标签。
        """
        response = self.stub.CreateVertexLabel(
            schema_service_pb2.CreateVertexLabelRequest(session_id=session_id, graph_id=graph_id,
                                                        label_name=label_name, if_not_exists=if_not_exists))
        if response.success:
            logger.debug("Create vertex label: " + label_name + " successfully")
            return Label(type=EntityType.VERTEX, label_name=response.label_name, label_id = response.label_id)
        else:
            raise JiuyuanException(response.error_message)

    def create_edge_label(self, session_id, graph_id, label_name, if_not_exists=True) -> Label:
        """
        在图中创建新的边标签。

        Args:
            : session_id: 会话ID。
            : graph_id: 新标签所在的图id。
            : label_name: 边的标签名。
            : if_not_exists: 当设置为 true 时，如果标签不存在则创建新标签，如果标签存在则返回已存在的标签。当设置为 false 时，如果标签不存在则创建新标签，如果标签存在则创建失败。

        Returns:
            : 新创建的边标签。
        """
        response = self.stub.CreateEdgeLabel(schema_service_pb2.CreateEdgeLabelRequest(session_id=session_id, graph_id=graph_id,
                                                                            label_name=label_name,
                                                                            if_not_exists=if_not_exists))
        if response.success:
            logger.debug("Create edge label: " + label_name + " successfully")
            return Label(type=EntityType.EDGE, label_name=response.label_name, label_id = response.label_id)
        else:
            raise JiuyuanException(response.error_message)

    def load_vertices_from_file(self, session_id, graph_id, label_name, data_path):
        """
        将数据路径下的点数据导入到对应的图中。

        Args:
            : session_id: 会话ID。
            : graph_id: 导入数据的图id。
            : label_name: 导入数据的点标签名称。
            : data_path: 点数据所在路径。
        """
        response = self.stub.LoadVertices(schema_service_pb2.LoadVerticesRequest(session_id=session_id, graph_id=graph_id,
                                                                      label_name=label_name, data_path=data_path))
        if response.success:
            logger.debug("Load " + label_name + " vertices successfully")
        else:
            raise JiuyuanException(response.error_message)

    def load_edges_from_file(self, session_id, graph_id, label_name, data_path):
        """
        将数据路径下的边数据导入到对应的图中。

        Args:
            : session_id: 会话ID。
            : graph_id: 导入数据的图id。
            : label_name: 导入数据的边标签名称。
            : data_path: 边数据所在路径。
        """
        response = self.stub.LoadEdges(schema_service_pb2.LoadEdgesRequest(session_id=session_id, graph_id=graph_id,
                                                                label_name=label_name, data_path=data_path))
        if response.success:
            logger.debug("Load " + label_name + " edges successfully")
        else:
            raise JiuyuanException(response.error_message)

    def project_graph(self, session_id, graph_id, filters) -> MemoryGraph:
        """
        从指定图中提取一张内存子图并存储到文件中。

        Args:
            : session_id: 会话ID。
            : graph_id: 被提取的原图ID。
            : filters: 内存子图过滤条件。

        Returns:
            : 从指定图中提取的内存子图。
        """
        response = self.stub.Project(schema_service_pb2.ProjectRequest(
            session_id=session_id, graph_id=graph_id, filters=filters.to_dict()))
        if response.success:
            logger.debug("Project memory graph " + response.memory_graph_id + " successfully")
            return MemoryGraph(id=response.memory_graph_id)
        else:
            raise JiuyuanException(response.error_message)
        

    def export_graph_label(self, session_id, graph_name, label, output_path, entity_type, with_header):
        """
        导出图中特定标签中的数据。

        Args:
            : session_id: 会话ID。
            : graph_name: 导出的图名称。
            : label: 导出的标签名。
            : output_path: 导出的路径。
            : entity_type: 导出的数据类型(边、点)。
            : with_header: 导出文件是否需要表头。
        """
        response = self.stub.ExportGraphLabel(schema_service_pb2.ExportGraphLabelRequest(
            session_id=session_id, graph=graph_name, label=label, outputPath=output_path,
            entityType=entity_type, withHeader=with_header))
        if response.success:
            logger.debug("Export graph " + graph_name + ", label " + label + " successfully")
        else:
            raise JiuyuanException(response.error_message)


class RequestHandler:
    def __init__(self, host, port, user, password, database_name):
        self.host = host
        self.port = port
        self.user = user
        self.password = password
        self.control_client = ControlServiceClient(host=host, port=port, user=user, password=password,
                                                   database_name=database_name)
        self.query_client = QueryServiceClient(host=host, port=port)
        self.schema_client = SchemaServiceClient(host=host, port=port)


class JiuyuanClient:
    DEFAULT_POOL_SIZE = 30

    def __init__(self, host, port, user, password, database_name, max_size=DEFAULT_POOL_SIZE):
        self.request_handler = RequestHandler(host, port, user, password, database_name)

        self.pool_size = max_size
        self.pool = Queue(self.pool_size)
        self.semaphore = threading.Semaphore(self.pool_size)

    def get_session(self) -> Session:
        """
        获取一个连接至指定数据库的会话实例，若不存在可用的实例则创建一个新会话。

        Returns:
            : 一个会话实例。
        """
        self.semaphore.acquire()
        if not self.pool.empty():
            session = self.pool.get()
            return session
        else:
            session_id = self.request_handler.control_client.create_session()
            if session_id is None:
                self.semaphore.release()
                raise JiuyuanException("Get session failed, no available session")
            return Session(session_id, self.request_handler)

    def release_session(self, session):
        """
        释放当前会话，会将此会话放到会话池中供后续分配使用。

        Args:
            : session: 需要释放的会话对象。
        """
        self.pool.put(session)
        self.semaphore.release()

    def close_sessions(self):
        """
        关闭客户端的全部会话。
        """
        while not self.pool.empty():
            self.semaphore.acquire()
            session = self.pool.get()
            assert session is not None, "session in pool cannot be None"
            self.request_handler.control_client.drop_session(session.session_id)
            self.semaphore.release()
