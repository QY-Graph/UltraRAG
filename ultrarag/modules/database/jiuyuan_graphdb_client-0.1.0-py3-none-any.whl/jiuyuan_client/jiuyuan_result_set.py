import logging
import age
from typing import List, Dict
from jiuyuan_db.model.entity import Vertex, Edge, Path

logger = logging.getLogger("JiuyuanResultSet")


class JiuyuanResultSet:
    def __init__(self, column_names=[], result_list=[]):
        self.column_names = column_names
        self.result_list = result_list
        # column index starts from 1
        self.column_name_index = {
            column_name: i + 1 for i, column_name in enumerate(column_names)}
        self.next_position = 0

    def __iter__(self):
        return self

    def __next__(self):
        if self.next_position < len(self.result_list):
            self.next_position += 1
            return self
        else:
            raise StopIteration

    def get_column_count(self) -> int:
        """
        获取结果集的列的数量。
        
        Returns:
            : 列数。
        """
        return len(self.column_names)

    def next(self) -> bool:
        """
        指向到下一行数据。
        
        Returns:
            : 将指针移到数据集下一行，成功则返回 true。当指针超过最后一行时，返回 false。
        """
        self.next_position += 1
        return self.next_position <= len(self.result_list)

    def get_object(self, column_index: int):
        """
        获取对象。

        Args:
        : column_index: 列的索引。

        Returns:
            : 列的索引对应的对象。     
        """
        if self.next_position == 0 or self.next_position > len(self.result_list):
            logger.error(f"Result set is not positioned on a valid row. Current position is {self.next_position}")
            return None
        if not 0 < column_index <= len(self.column_names):
            logger.error(f"Column index {column_index} is out of range. Column count is {len(self.column_names)}")
            return None
        return self.result_list[self.next_position - 1][column_index - 1]

    def get_object_by_name(self, column_name: str):
        """
        获取对象。

        Args:
        : column_name: 列的名称。

        Returns:
            : 列的名称对应的对象。     
        """
        column_index = self.column_name_index.get(column_name)
        return self.get_object(column_index)

    def get_string(self, column_index: int) -> str:
        """
        将对象以字符串类型读取。

        Args:
        : column_index: 列的索引。

        Returns:
            : 字符串的对象。
        """
        return str(self.get_object(column_index))

    def get_string_by_name(self, column_name: str) -> str:
        """
        将对象以字符串类型读取。

        Args:
        : column_name: 列的名称。

        Returns:
            : 字符串的对象。
        """
        return str(self.get_object_by_name(column_name))

    def get_int(self, column_index: int) -> int:
        """
        将对象以 Int 类型读取。

        Args:
        : column_index: 列的索引。

        Returns:
            : Int类型的对象值。
        """
        return int(self.get_object(column_index))

    def get_int_by_name(self, column_name: str) -> int:
        """
        将对象以 Int 类型读取。

        Args:
        : column_name: 列的名称。

        Returns:
            : Int类型的对象值。
        """
        return int(self.get_object_by_name(column_name))

    def get_long(self, column_index: int) -> int:
        """
        将对象以 Long 类型读取。

        Args:
        : column_index: 列的索引。

        Returns:
            : Long类型的对象值。
        """
        return int(self.get_object(column_index))

    def get_long_by_name(self, column_name: str) -> int:
        """
        将对象以 Long 类型读取。

        Args:
        : column_name: 列的名称。

        Returns:
            : Long类型的对象值。
        """
        return int(self.get_object_by_name(column_name))

    def get_double(self, column_index: int) -> float:
        """
        将对象以 Double 类型读取。

        Args:
        : column_index: 列的索引。

        Returns:
            : Double类型的对象值。
        """
        return float(self.get_object(column_index))

    def get_double_by_name(self, column_name: str) -> float:
        """
        将对象以 Double 类型读取。

        Args:
        : column_name: 列的名称。

        Returns:
            : Double类型的对象值。
        """
        return float(self.get_object_by_name(column_name))

    def get_result_list(self) -> List[Dict]:
        """
        获取结果列表。

        Returns:
            : 结果列表。
        """
        return self.result_list

    def get_column_names(self) -> List[str]:
        """
        获取列的名称列表。

        Returns:
            : 名称列表。
        """
        return self.column_names

    def get_column_name_index(self) -> Dict[str, int]:
        """
        获取列的名称索引。

        Returns:
            : 名称索引。
        """
        return self.column_name_index

    def get_vertex(self, column_index: int):
        """
        将对象以点的格式读取。

        Args:
        : column_index: 列的索引。

        Returns:
            : 对象的点。
        """
        age_vertex = age.parseAgeValue(self.get_string(column_index))
        return Vertex(age_vertex.id, age_vertex.label, age_vertex.properties)

    def get_vertex(self, column_name: str):
        """
        将对象以点的格式读取。

        Args:
        : column_name: 列的名称。

        Returns:
            : 对象的点。
        """
        index = self.column_name_index.get(column_name)
        return self.get_vertex(index)
    def get_edge(self, column_index: int):
        """
        将对象以边的格式读取。

        Args:
        : column_index: 列的索引。

        Returns:
            : 对象的边。
        """
        age_edge = age.parseAgeValue(self.get_string(column_index))
        return Edge(age_edge.id, age_edge.label, age_edge.start_id, age_edge.end_id, age_edge.properties)

    def get_edge_(self, column_name: str):
        """
        将对象以边的格式读取。

        Args:
        : column_name: 列的名称。

        Returns:
            : 对象的边。
        """
        index = self.column_name_index.get(column_name)
        return self.get_edge(index)
    def get_path(self, column_index: int):
        """
        将对象以路径的格式读取。

        Args:
        : column_index: 列的索引。

        Returns:
            : 对象的路径。
        """
        age_path = age.parseAgeValue(self.get_string(column_index))
        return Path(age_path.entities)
    def get_path_by_name(self, column_name: str):
        """
        将对象以路径的格式读取。

        Args:
        : column_name: 列的名称。

        Returns:
            : 对象的路径。
        """
        index = self.column_name_index.get(column_name)
        return self.get_path(index)
    def __str__(self):
        # Calculate maximum width for each column
        column_widths = [max(len(str(item)) for item in column) for column in zip(self.column_names, *self.result_list)]

        # Generate table string
        table_str = ""

        # Append column headers
        for i, column_name in enumerate(self.column_names):
            table_str += f"{column_name:<{column_widths[i]}} | "
        table_str += "\n"

        # Append separator line
        for width in column_widths:
            table_str += "-" * width + " | "
        table_str += "\n"

        # Append data rows
        for row in self.result_list:
            for i, item in enumerate(row):
                table_str += f"{item:<{column_widths[i]}} | "
            table_str += "\n"

        return table_str



def from_proto(proto_message):
    """
    将protobuf message反序列化为结果列表。

    Args:
    : proto_message: 结果列表的消息对象。

    Returns:
        : 结果列表对象。
    """
    column_names = proto_message.column_names
    result_list = []
    for proto_record in proto_message.result_list:
        jy_record = []
        for field in proto_record.record:
            jy_record.append(field)
        result_list.append(jy_record)
    return JiuyuanResultSet(column_names, result_list)

def merge_jiuyuan_result_set(result_list):
    """
    合并结果列表

    Args:
    : result_list: 结果列表。

    Returns:
        : 合并后的结果列表。
    """
    if not result_list:
        return None

    merged_list = result_list[0].result_list
    column_names = result_list[0].column_names

    for i in range(1, len(result_list)):
        if result_list[i].column_names != result_list[i - 1].column_names:
            raise Exception("Columns do not match")
        merged_list.extend(result_list[i].result_list)

    return JiuyuanResultSet(column_names, merged_list)
