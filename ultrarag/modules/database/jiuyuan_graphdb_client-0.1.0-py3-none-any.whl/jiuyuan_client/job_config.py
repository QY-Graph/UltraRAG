import json
import logging
from typing import List, Dict
from enum import Enum

logger = logging.getLogger(__name__)

class AnalyticJobEnum(Enum):


    PAGERANK = "pagerank"
    """
    网页排名算法。
    """

    SSSP = "sssp"
    """
    单源最短路径算法（Single Source Shortest Path）。
    """

    BFS = "bfs"
    """
    广度优先搜索算法（Breadth-first Search）。
    """

    ALL_PAIR_SSSP = "all_pair_sssp"
    """
    全点对最短路径（All Pairs Shortest Path）。
    """

    CC = "cc"
    """
    距离中心度（Closeness Centrality）。
    """

    DC = "dc"
    """
    度数关联度（Degree Correlation）。
    """

    HITS = "hits"
    """
    超链接主题搜索（Hyperlink-Induced Topic Search）。
    """

    KCORE = "kcore"
    """
    K核算法（K-core）。
    """

    KHOP = "khop"
    """
    K度邻居（K-Hop）。
    """

    MSSP = "mssp"
    """
    多源最短路径（Multiple-source Shortest Paths）。
    """

    SSNP = "ssnp"
    """
    单源最窄路径（Single-Source Narrowest Path）。
    """

    SSWP = "sswp"
    """
    单源最宽路径（Single-Source Widest Path）。
    """

    TREE_STAT = "tree_stat"
    """
    树深度。
    """

    WCC = "wcc"
    """
    弱连通分量（Weakly Connected Components）。
    """

    WCC_UNDIRECT = "wcc_undirect"
    """
    无向图弱连通分量（Weakly Connected Components）。
    """

    WPAGERANK = "wpagerank"
    """
    带权重的网页排序（Weighted Pagerank Algorithm）。
    """

class AnalyticJobConfigConstant:
    LOAD_CONCURRENCY = "load_concurrency"
    """
    分析任务单节点上总的线程数。
    """

    COROUTINES_CONCURRENCY = "coroutines_concurrency"
    """
    分析任务单节点上总的线程数。
    """

    REDUCER_CONCURRENCY = "reducer_concurrency"
    """
    分析任务单节点上消息聚合的并发度。
    """
    
    SPLIT_CONCURRENCY = "split_concurrency"
    """
    分析任务单节点上的计算任务的并发度。
    """


class AnalyticNode:
    def __init__(self, host: str = "", ssh_port: int = 22):
        self._host = host
        self._ssh_port = ssh_port

    @property
    def host(self):
        """
        节点的host IP
        """ 
        return self._host

    @property
    def ssh_port(self):
        """
        节点的端口号
        """
        return self._ssh_port

    @host.setter
    def host(self, host: str):
        self._host = host

    @ssh_port.setter
    def ssh_port(self, ssh_port: int):
        self._ssh_port = ssh_port

    def to_dict(self):
        """
        将参数转换成字典形式存储

        Returns:
            : 包含host IP和端口号的字典
        """
        return {"host": self._host, "ssh_port": self._ssh_port}

class AnalyticJobConfig:
    def __init__(self, nodes: List[AnalyticNode] = [], port: str = "", job_name: str = "", args=None):
        self._nodes = nodes
        self._port = port
        self._job_name = job_name
        self._args = args

    @property
    def nodes(self):
        """
        分析算法运⾏的节点列表
        """
        return self._nodes

    @property
    def job_name(self):
        """
        分析算法的名称
        """
        return self._job_name

    @property
    def port(self):
        """
        分析任务节点之间通信的端⼝
        """
        return self._port

    @property
    def args(self):
        """
        分析算法的参数
        """
        return self._args

    @nodes.setter
    def nodes(self, nodes):
        self._nodes = nodes

    @port.setter
    def port(self, port: str):
        self._port = port

    @job_name.setter
    def job_name(self, job_name: str):
        self._job_name = job_name

    @args.setter
    def args(self, value):
        self._args = value

    def add_arg(self, key: str, value: str):
        """
        添加参数

        Args:
        : key: 参数名称。
        : value: 参数值。

        Returns:
            : 包含参数和值的字典键值对。
        """
        self._args[key] = value

    def validate_config(self) -> bool:
        """
        验证配置参数中的算法是否支持

        Returns:
            : 若参数中的算法支持则返回 true，否则返回返回 false。
        """
        algs = {alg.value for alg in AnalyticJobEnum}
        if self._job_name not in algs:
            logger.error(f"Cannot find algorithm: {self._job_name}")
            return False
        return True

    def to_dict(self):
        """
        将参数转换成字典形式存储

        Returns:
            : 包含全部参数的字典
        """
        config = {}
        config['job_name'] = self._job_name
        config['nodes'] = [node.to_dict() for node in self._nodes]
        config['port'] = self._port
        config['parameters'] = self._args
        return config


'''
 sample config in json

 {
  "nodes": [
    {"host":"192.168.1.76", "ssh_port":22}
  ],
  "port": "8888",
  "job_name": "pagerank",
  "args": {
    "reducer_concurrency": "15"
  }
}
'''
def parse_config_from_json(file_path):
    """
    从Json中解析配置参数

    Args:
    : file_path: 文件路径。

    Returns:
        : 分析任务配置参数对象
    """
    with open(file_path, 'r') as file:
        data = json.load(file)
        nodes = [AnalyticNode(host=node_data['host'], ssh_port=node_data['ssh_port'])
                    for node_data in data.get('nodes', [])]
        port = data.get('port', "")
        job_name = data.get('job_name', "")
        args = data.get('args', {})
        return AnalyticJobConfig(nodes, port, job_name, args)
