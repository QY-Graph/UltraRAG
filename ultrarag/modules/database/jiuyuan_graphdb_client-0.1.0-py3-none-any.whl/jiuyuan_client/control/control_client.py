from jiuyuan_db.rpc import control_service_pb2, control_service_pb2_grpc
from jiuyuan_db.abstract_client import AbstractClient

class ControlServiceClient(AbstractClient):
    def __init__(self, host, port):
        super().__init__(host, port)
        self.stub = control_service_pb2_grpc.JiuyuanGraphDatabaseControlServiceStub(self.channel)

    def create_session(self):
        response = self.stub.CreateSession(control_service_pb2.CreateSessionRequest())
        return response.session_id

