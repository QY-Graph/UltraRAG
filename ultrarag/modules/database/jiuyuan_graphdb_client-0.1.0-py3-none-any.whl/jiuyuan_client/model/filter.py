import json

VERTEX_TYPE = "VERTEX"
EDGE_TYPE = "EDGE"


class SingleFilter:
    def __init__(self, entity_type, label_name):
        self.type = entity_type
        self.labelName = label_name

    def to_dict(self):
        """
        将标签过滤器的类型和名称转换成字典形式

        Returns:
            : 包含一个标签过滤器的字典
        """
        return {
            "type": self.type,
            "labelName": self.labelName
        }


class MemoryGraphFilter:
    def __init__(self, filters):
        self.filters = filters

    def add_filter(self, filter):
        """
        增加一个标签过滤器

        Returns:
            : 增加后的子图过滤器。
        """
        self.filters.append(filter)

    def to_dict(self):
        """
        将标签过滤器列表转换成字典形式

        Returns:
            : 包含标签过滤器列表的字典
        """
        return {
            "filters": [filter.to_dict() for filter in self.filters]
        }


'''
 sample config in json
 
 {
  "filters": [
    {"entity_type":"VERTEX", "label_name":"Person"},
    {"entity_type":"EDGE", "label_name":"Knows"}
  ]
}
'''


def parse_config_from_json(file_path):
    """
    从Json中解析配置参数

    Args:
    : file_path: 文件路径。

    Returns:
        : 子图过滤器
    """
    with open(file_path, 'r') as file:
        data = json.load(file)
        filters = [SingleFilter(entity_type=filter['entity_type'],
                                label_name=filter['label_name'])
                   for filter in data.get('filters', [])]
        return MemoryGraphFilter(filters=filters)
