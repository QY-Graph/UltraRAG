class MemoryGraph:
    def __init__(self, id):
        self.id = id
