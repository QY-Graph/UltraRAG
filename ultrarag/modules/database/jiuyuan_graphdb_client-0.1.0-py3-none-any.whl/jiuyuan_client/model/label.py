class Label:
    def __init__(self, type, label_name, label_id):
        self.type = type
        self.label_name = label_name
        self.label_id = label_id


