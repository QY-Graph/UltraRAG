from io import StringIO
from enum import Enum

class EntityType(Enum):
    NONE = 0
    """
    不存在的实体类型
    """    

    VERTEX = 1
    """
    点类型。
    """   

    EDGE = 2
    """
    边类型。
    """  

    PATH = 3
    """
    路径类型。
    """  

class Entity:
    @property
    def gtype(self):
        return EntityType.NONE

class Vertex(Entity):
    def __init__(self, id=None, label=None, properties=None) -> None:
        self.id = id
        self.label = label
        self.properties = properties

    @property
    def gtype(self):
        return EntityType.VERTEX

    def __setitem__(self, name, value):
        self.properties[name] = value

    def __getitem__(self, name):
        if name in self.properties:
            return self.properties[name]
        else:
            return None

    def __str__(self) -> str:
        return self.toString()

    def __repr__(self) -> str:
        return self.toString()

    def toString(self) -> str:
        """
        将点的属性转换为字符串形式

        Returns:
            : 点属性的字符串表示。
        """
        return nodeToString(self)

    def _toString(self, buf):
        _nodeToString(self, buf)

class Edge(Entity):
    def __init__(self, id=None, label=None, start_id = None, end_id = None, properties=None) -> None:
        self.id = id
        self.label = label
        self.start_id = start_id
        self.end_id = end_id
        self.properties = properties

    @property
    def gtype(self):
        return EntityType.EDGE

    def __setitem__(self, name, value):
        self.properties[name] = value

    def __getitem__(self, name):
        if name in self.properties:
            return self.properties[name]
        else:
            return None

    def __str__(self) -> str:
        return self.toString()

    def __repr__(self) -> str:
        return self.toString()

    def extraStrFormat(node, buf):
        """
        将边的开始和结束id寄存在缓冲区。

        Args:
        : node: 节点。
        : buf: StringIO对象。
        """
        if node.start_id != None:
            buf.write(", start_id:")
            buf.write(str(node.start_id))

        if node.end_id != None:
            buf.write(", end_id:")
            buf.write(str(node.end_id))

    def toString(self) -> str:
        """
        将边的属性转换为字符串形式

        Returns:
            : 边属性的字符串表示。
        """
        return nodeToString(self, Edge.extraStrFormat)

    def _toString(self, buf):
        _nodeToString(self, buf, Edge.extraStrFormat)

class Path(Entity):
    entities = []

    def __init__(self, entities=None) -> None:
        self.entities = entities

    @property
    def gtype(self):
        return EntityType.PATH

    def __iter__(self):
        return self.entities.__iter__()

    def __len__(self):
        return self.entities.__len__()

    def __getitem__(self, index):
        return self.entities[index]

    def size(self):
        """
        路径的大小

        Returns:
            : 路径的大小。
        """
        return self.entities.__len__()

    def append(self, entity: Entity):
        """
        添加路径

        Returns:
            : 路径列表。
        """
        self.entities.append(entity)

    def __str__(self) -> str:
        return self.toString()

    def __repr__(self) -> str:
        return self.toString()

    def toString(self) -> str:
        """
        将路径的属性转换为字符串形式

        Returns:
            : 路径属性的字符串表示。
        """
        buf = StringIO()
        buf.write("[")
        max = len(self.entities)
        idx = 0
        while idx < max:
            if idx > 0:
                buf.write(",")
            self.entities[idx]._toString(buf)
            idx += 1
        buf.write("]::PATH")

        return buf.getvalue()

def nodeToString(node, extraFormatter=None):
    """
    将寄存在内存缓冲区的实体属性转换成字符串。

    Returns:
        : 对应实体属性的字符串。
    """
    buf = StringIO()
    _nodeToString(node, buf, extraFormatter=extraFormatter)
    return buf.getvalue()


def _nodeToString(node, buf, extraFormatter=None):
    buf.write("{")
    if node.label != None:
        buf.write("label:")
        buf.write(node.label)

    if node.id != None:
        buf.write(", id:")
        buf.write(str(node.id))

    if node.properties != None:
        buf.write(", properties:{")
        for k, v in node.properties.items():
            buf.write(k)
            buf.write(": ")
            buf.write(str(v))
            buf.write(", ")
        buf.write("}")

    if extraFormatter != None:
        extraFormatter(node, buf)

    if node.gtype == EntityType.VERTEX:
        buf.write("}::VERTEX")
    if node.gtype == EntityType.EDGE:
        buf.write("}::EDGE")
